![ALT](/media/images/gemm-hierarchy-with-epilogue-no-labels.png "CUTLASS")

[README](/README.md#documentation) > **Contributors**

# CUTLASS Developers and Contributors

This is the official list of CUTLASS developers and contributors.

## DEVELOPERS
Andrew Kerr  
Haicheng Wu  
Manish Gupta  
Dustyn Blasig  
Pradeep Ramani  
Naila Farooqui  
Piotr Majcher  
Paul Springer  
Jin Wang   
Aniket Shivam  
Chinmay Talegaonkar  
Shang Zhang   
Scott Yokim      
Markus Hohnerbach  
Aditya Atluri  
David Tanner  
  
## CONTRIBUTORS
Timothy Costa  
Julien Demouth  
Brian Fahs  
Michael Goldfarb  
Mostafa Hagog  
Fei Hu  
Alan Kaatz  
Tina Li  
Timmy Liu  
Duane Merrill  
Kevin Siu  
Markus Tavenrath  
John Tran  
Vicki Wang  
Junkai Wu  
Fung Xie  
Albert Xu  
Jack Yang  
Xiuxia Zhang  
Nick Zhao  

## ACKNOWLEDGEMENTS

Girish Bharambe  
Cris Cecka  
Luke Durant  
Olivier Giroux  
Stephen Jones  
Rishkul Kulkarni  
Bryce Lelbach  
Matthew Nicely  
Joel McCormack  
Kyrylo Perelygin  


